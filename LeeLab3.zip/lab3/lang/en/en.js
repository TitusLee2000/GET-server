module.exports = {
  greeting: 'Hello %1, What a beautiful day. Server current date and time is ',
};
