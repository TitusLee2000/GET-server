exports.getDate = function () {
  return new Date().toString();
};
